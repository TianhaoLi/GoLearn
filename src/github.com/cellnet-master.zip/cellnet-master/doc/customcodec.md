# 定制Codec
cellnet内建提供基本的编码格式，如果有新的编码需要增加时，可以将这些编码注册到cellnet中。

定制一个自己的Codec，可以直接参考codec/json包下的例子即可。