package udp

import (
	"github.com/davyxu/golog"
)

var log = golog.New("udpproc")
